package forest;


public class Constants
{

  public static int FONT_SIZE = 12;

  public static int HORIZONTAL_INTERVAL = 25;

  public static int VERTICAL_INTERVAL = 2;

}
